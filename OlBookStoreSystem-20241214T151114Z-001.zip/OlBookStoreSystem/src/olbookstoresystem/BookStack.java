/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package olbookstoresystem;

// BookStack.java
public class BookStack {

    // Inner class to represent a stack node
    class StackNode {
        String bookTitle;
        StackNode next;

        public StackNode(String bookTitle) {
            this.bookTitle = bookTitle;
            next = null;
        }
    }

    private StackNode top;

    // Constructor to initialize the stack
    public BookStack() {
        top = null;
    }

    // Method to push a book onto the stack
    public void push(String bookTitle) {
        StackNode newNode = new StackNode(bookTitle);
        newNode.next = top;
        top = newNode;
    }

    // Method to pop a book from the stack
    public String pop() {
        if (top == null) {
            return null;  // Stack is empty
        }
        String bookTitle = top.bookTitle;
        top = top.next;
        return bookTitle;
    }

    // Method to peek the book on top of the stack
    public String peek() {
        if (top == null) {
            return null;  // Stack is empty
        }
        return top.bookTitle;
    }

    // Method to check if the stack is empty
    public boolean isEmpty() {
        return top == null;
    }
}
