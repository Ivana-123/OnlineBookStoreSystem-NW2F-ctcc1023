/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package olbookstoresystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {

    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginFrame() {
        // Set title for the login frame
        setTitle("Customer Login");

        // Set layout manager
        setLayout(new FlowLayout());

        // Initialize components
        usernameLabel = new JLabel("Username:");
        passwordLabel = new JLabel("Password:");
        usernameField = new JTextField(20);  // 20 is the width of the text field
        passwordField = new JPasswordField(20);  // 20 is the width of the password field
        loginButton = new JButton("Login");

        // Add action listener for the login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        // Add components to the JFrame
        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(loginButton);

        // Set default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set size of the window
        setSize(300, 200);

        // Center the window on the screen
        setLocationRelativeTo(null);

        // Make the window visible
        setVisible(true);
    }

    // Method to handle login logic
    private void login() {
        String username = usernameField.getText();
        char[] password = passwordField.getPassword();

        // Simple hardcoded credentials for demo purposes
        String correctUsername = "customer";
        String correctPassword = "password123";

        // Check if the entered credentials match the correct ones
        if (username.equals(correctUsername) && new String(password).equals(correctPassword)) {
            JOptionPane.showMessageDialog(this, "Login Successful!");
            
            dispose();
            new MainFrame();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials. Please try again.");
        }
    }

    public static void main(String[] args) {
        new LoginFrame();  // Create and show the login frame
    }
}

