/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package olbookstoresystem;

// BookTree.java
public class BookTree {

    // Inner class to represent a tree node
    class TreeNode {
        String bookTitle;
        TreeNode left, right;

        public TreeNode(String bookTitle) {
            this.bookTitle = bookTitle;
            left = right = null;
        }
    }

    private TreeNode root;

    // Constructor to initialize the tree
    public BookTree() {
        root = null;
    }

    // Method to insert a book into the tree
    public void insert(String bookTitle) {
        root = insertRec(root, bookTitle);
    }

    // Recursive method to insert a book into the tree
    private TreeNode insertRec(TreeNode root, String bookTitle) {
        if (root == null) {
            root = new TreeNode(bookTitle);
            return root;
        }

        // If the book title is less than the root, insert it in the left subtree
        if (bookTitle.compareTo(root.bookTitle) < 0) {
            root.left = insertRec(root.left, bookTitle);
        } 
        // If the book title is greater than the root, insert it in the right subtree
        else if (bookTitle.compareTo(root.bookTitle) > 0) {
            root.right = insertRec(root.right, bookTitle);
        }

        return root;
    }

    // Method to search for a book in the tree
    public boolean search(String bookTitle) {
        return searchRec(root, bookTitle);
    }

    // Recursive method to search for a book in the tree
    private boolean searchRec(TreeNode root, String bookTitle) {
        // Base case: the book is not found or we reach the leaf node
        if (root == null) {
            return false;
        }

        // If the book title is equal to the root's title, we found the book
        if (root.bookTitle.equals(bookTitle)) {
            return true;
        }

        // If the book title is less than the root, search in the left subtree
        if (bookTitle.compareTo(root.bookTitle) < 0) {
            return searchRec(root.left, bookTitle);
        }

        // Otherwise, search in the right subtree
        return searchRec(root.right, bookTitle);
    }
}

