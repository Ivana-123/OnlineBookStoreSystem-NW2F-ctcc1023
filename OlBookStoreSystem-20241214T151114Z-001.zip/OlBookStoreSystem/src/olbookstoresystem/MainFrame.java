/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package olbookstoresystem;

import javax.swing.*; 
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;

// Main class that sets up the GUI for the Online Bookstore System
public class MainFrame extends JFrame {

    // Declare components
    private JLabel titleLabel;
    private JTextField bookTitleField;
    private JButton searchButton;
    private JButton sortButton;
    private JButton addToQueueButton;
    private JButton checkoutButton;
    private JButton undoButton;  // Undo Checkout Button
    private JTextArea availableBooksArea;
    private JTextArea resultArea;

    // LinkedList to store book titles
    private LinkedList<String> bookList;

    // Queue to represent book checkout line
    private Queue<String> checkoutQueue;

    // Binary Search Tree to store books
    private BookTree bookTree;

    // Stack for undoing checkout
    private BookStack undoStack;

    public MainFrame() {
        // Set title
        setTitle("Online Bookstore System");

        // Set layout manager
        setLayout(new FlowLayout());

        // Initialize components
        titleLabel = new JLabel("Enter Book Title:");
        bookTitleField = new JTextField(20);  // 20 is the width of the text field
        searchButton = new JButton("Search Book");
        sortButton = new JButton("Sort Books");
        addToQueueButton = new JButton("Add to Queue");
        checkoutButton = new JButton("Checkout Book");
        undoButton = new JButton("Undo Checkout");  // Initialize Undo button
        availableBooksArea = new JTextArea(10, 30);  // Text area to display available books
        availableBooksArea.setEditable(false);  // Make it non-editable
        resultArea = new JTextArea(5, 30);  // Text area to display results
        resultArea.setEditable(false);  // Make it non-editable

        // Initialize the book list with famous books
        bookList = new LinkedList<>();
        bookList.add("The Great Gatsby");
        bookList.add("To Kill a Mockingbird");
        bookList.add("1984");
        bookList.add("Moby-Dick");
        bookList.add("Pride and Prejudice");
        bookList.add("The Catcher in the Rye");
        bookList.add("Harry Potter and the Sorcerer's Stone");

        // Initialize the checkout queue
        checkoutQueue = new LinkedList<>();

        // Initialize the book tree
        bookTree = new BookTree();

        // Initialize the undo stack
        undoStack = new BookStack();

        // Insert books into the tree
        for (String book : bookList) {
            bookTree.insert(book);
        }

        // Add action listener for the search button
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String bookTitle = bookTitleField.getText();
                searchBook(bookTitle);
            }
        });

        // Add action listener for the sort button
        sortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortBooks();
            }
        });

        // Add action listener for the "Add to Queue" button
        addToQueueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String bookTitle = bookTitleField.getText();
                addToQueue(bookTitle);
            }
        });

        // Add action listener for the "Checkout Book" button
        checkoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkoutBook();
            }
        });

        // Add action listener for the "Undo Checkout" button
        undoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                undoCheckout();
            }
        });

        // Add components to the JFrame
        add(titleLabel);
        add(bookTitleField);
        add(searchButton);
        add(sortButton);
        add(addToQueueButton);
        add(checkoutButton);
        add(undoButton);  // Add the Undo button to the UI
        add(new JScrollPane(availableBooksArea));  // Scrollable area for available books
        add(new JScrollPane(resultArea));  // Scrollable result area

        // Set default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set size of the window
        setSize(600, 400);

        // Center the window on the screen
        setLocationRelativeTo(null);

        // Make the window visible
        setVisible(true);

        // Initialize the available books display
        updateAvailableBooksList();
    }

    // Method to update the available books list display
    private void updateAvailableBooksList() {
        StringBuilder availableBooksText = new StringBuilder("Available Books:\n");
        for (String book : bookList) {
            if (!checkoutQueue.contains(book)) {
                availableBooksText.append(book).append("\n");
            }
        }
        availableBooksArea.setText(availableBooksText.toString());
    }

    // Method to search for the book using the binary search tree
    private void searchBook(String bookTitle) {
        boolean found = bookTree.search(bookTitle);
        if (found) {
            resultArea.setText("Book found: " + bookTitle);
        } else {
            resultArea.setText("Book not found: " + bookTitle);
        }
    }

    // Method to sort the book list alphabetically
    private void sortBooks() {
        Collections.sort(bookList);
        updateAvailableBooksList();  // Update the available books list after sorting
        StringBuilder result = new StringBuilder("Sorted Books:\n");
        for (String book : bookList) {
            result.append(book).append("\n");
        }
        resultArea.setText(result.toString());
    }

    // Method to add a book to the checkout queue
    private void addToQueue(String bookTitle) {
        if (bookList.contains(bookTitle) && !checkoutQueue.contains(bookTitle)) {
            checkoutQueue.add(bookTitle);
            bookList.remove(bookTitle);  // Remove it from the available list
            updateAvailableBooksList();  // Update the available books list
            resultArea.setText("Added to Checkout Queue: " + bookTitle);
        } else {
            resultArea.setText("Book not found or already in queue: " + bookTitle);
        }
    }

    // Method to process the checkout (dequeue the first book)
    private void checkoutBook() {
        if (!checkoutQueue.isEmpty()) {
            String book = checkoutQueue.poll();
            undoStack.push(book);  // Push the checked-out book onto the stack
            updateAvailableBooksList();  // Update the available books list
            resultArea.setText("Checked Out: " + book);
        } else {
            resultArea.setText("No books in the checkout queue.");
        }
    }

    // Method to undo the last checkout (pop from the stack)
    private void undoCheckout() {
        String book = undoStack.pop();
        if (book != null) {
            resultArea.setText("Undo Checkout: " + book + " has been returned to the available books list.");
            bookList.add(book);  // Return the book to the available books list
            updateAvailableBooksList();  // Update the available books list
        } else {
            resultArea.setText("No checkout to undo.");
        }
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}



